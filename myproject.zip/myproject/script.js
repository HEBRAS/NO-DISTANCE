function hello() {
    alert("الموقع شغال 100%! 🎉");
}
